# FRA231-Robotics-Modelling-and-Experimentation-2024
 Guidelines for doing rmx's lab
