/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: TestEncoder.c
 *
 * Code generated for Simulink model 'TestEncoder'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Wed Oct 30 12:43:45 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "TestEncoder.h"
#include "TestEncoder_types.h"
#include "TestEncoder_private.h"
#include "rtwtypes.h"
#include "stm_timer_ll.h"

/* Block signals (default storage) */
B_TestEncoder_T TestEncoder_B;

/* Block states (default storage) */
DW_TestEncoder_T TestEncoder_DW;

/* Real-time model */
static RT_MODEL_TestEncoder_T TestEncoder_M_;
RT_MODEL_TestEncoder_T *const TestEncoder_M = &TestEncoder_M_;

/* Forward declaration for local functions */
static void TestEncoder_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj);
static void TestEncoder_SystemCore_setup_n(stm32cube_blocks_EncoderBlock_T *obj);
static void TestEncoder_SystemCore_setup_nb(stm32cube_blocks_EncoderBlock_T *obj);

/* System initialize for atomic system: */
void TestEncode_DigitalPortRead_Init(DW_DigitalPortRead_TestEncode_T *localDW)
{
  /* Start for MATLABSystem: '<S12>/Digital Port Read' */
  localDW->objisempty = true;
  localDW->obj.isInitialized = 1;
}

/* Output and update for atomic system: */
void TestEncoder_DigitalPortRead(B_DigitalPortRead_TestEncoder_T *localB)
{
  uint32_T pinReadLoc;

  /* MATLABSystem: '<S12>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S12>/Digital Port Read' */
  localB->DigitalPortRead = ((pinReadLoc & 8192U) != 0U);
}

static void TestEncoder_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM3;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void TestEncoder_SystemCore_setup_n(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM4;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder1' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void TestEncoder_SystemCore_setup_nb(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM8;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder2' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

/* Model step function */
void TestEncoder_step(void)
{
  real_T diff;
  uint32_T pinReadLoc;

  /* MATLABSystem: '<Root>/Encoder' */
  TestEncoder_B.bX4 = getTimerCounterValueForG4(TestEncoder_DW.obj_p.TimerHandle,
    false, NULL);
  TestEncoder_DigitalPortRead(&TestEncoder_B.DigitalPortRead);

  /* MATLAB Function: '<Root>/MATLAB Function2' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   */
  if (!TestEncoder_DW.bcount_not_empty_p) {
    TestEncoder_DW.bcount_c = TestEncoder_B.bX4;
    TestEncoder_DW.bcount_not_empty_p = true;
  }

  if (TestEncoder_B.DigitalPortRead.DigitalPortRead) {
    TestEncoder_DW.xcount_e = 0.0;
  } else {
    diff = (real_T)TestEncoder_B.bX4 - TestEncoder_DW.bcount_c;
    if (diff > 32760.0) {
      diff -= 65520.0;
    } else if (diff < -32760.0) {
      diff += 65520.0;
    }

    TestEncoder_DW.xcount_e += diff;
  }

  TestEncoder_DW.bcount_c = TestEncoder_B.bX4;
  TestEncoder_B.X4pulse = TestEncoder_DW.xcount_e;

  /* End of MATLAB Function: '<Root>/MATLAB Function2' */
  /* MATLABSystem: '<Root>/Encoder1' */
  TestEncoder_B.bX2 = getTimerCounterValueForG4(TestEncoder_DW.obj_h.TimerHandle,
    false, NULL);

  /* MATLAB Function: '<Root>/MATLAB Function1' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   */
  if (!TestEncoder_DW.bcount_not_empty_c) {
    TestEncoder_DW.bcount_m = TestEncoder_B.bX2;
    TestEncoder_DW.bcount_not_empty_c = true;
  }

  if (TestEncoder_B.DigitalPortRead.DigitalPortRead) {
    TestEncoder_DW.xcount_o = 0.0;
  } else {
    diff = (real_T)TestEncoder_B.bX2 - TestEncoder_DW.bcount_m;
    if (diff > 32760.0) {
      diff -= 65520.0;
    } else if (diff < -32760.0) {
      diff += 65520.0;
    }

    TestEncoder_DW.xcount_o += diff;
  }

  TestEncoder_DW.bcount_m = TestEncoder_B.bX2;
  TestEncoder_B.X2pulse = TestEncoder_DW.xcount_o;

  /* End of MATLAB Function: '<Root>/MATLAB Function1' */
  /* MATLABSystem: '<Root>/Encoder2' */
  TestEncoder_B.bX1 = getTimerCounterValueForG4(TestEncoder_DW.obj.TimerHandle,
    false, NULL);

  /* MATLAB Function: '<Root>/MATLAB Function3' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion2'
   */
  if (!TestEncoder_DW.bcount_not_empty) {
    TestEncoder_DW.bcount = TestEncoder_B.bX1;
    TestEncoder_DW.bcount_not_empty = true;
  }

  if (TestEncoder_B.DigitalPortRead.DigitalPortRead) {
    TestEncoder_DW.xcount = 0.0;
  } else {
    diff = (real_T)TestEncoder_B.bX1 - TestEncoder_DW.bcount;
    if (diff > 32760.0) {
      diff -= 65520.0;
    } else if (diff < -32760.0) {
      diff += 65520.0;
    }

    TestEncoder_DW.xcount += diff;
  }

  TestEncoder_DW.bcount = TestEncoder_B.bX1;
  TestEncoder_B.X1pulse = TestEncoder_DW.xcount;

  /* End of MATLAB Function: '<Root>/MATLAB Function3' */
  /* MATLABSystem: '<S14>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S14>/Digital Port Read' */
  TestEncoder_B.DigitalPortRead_j = ((pinReadLoc & 256U) != 0U);

  /* MATLABSystem: '<S16>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S16>/Digital Port Read' */
  TestEncoder_B.DigitalPortRead_g = ((pinReadLoc & 512U) != 0U);
  TestEncoder_DigitalPortRead(&TestEncoder_B.DigitalPortRead_o);

  /* MATLAB Function: '<Root>/MATLAB Function4' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   *  DataTypeConversion: '<Root>/Data Type Conversion4'
   */
  if (!TestEncoder_DW.previousA_not_empty_b) {
    TestEncoder_DW.previousA_a = TestEncoder_B.DigitalPortRead_j;
    TestEncoder_DW.previousA_not_empty_b = true;
  }

  if (TestEncoder_B.DigitalPortRead_o.DigitalPortRead) {
    TestEncoder_DW.position_accumulated_h = 0.0;
  } else if ((TestEncoder_DW.previousA_a == 0.0) &&
             TestEncoder_B.DigitalPortRead_j) {
    if (!TestEncoder_B.DigitalPortRead_g) {
      TestEncoder_DW.position_accumulated_h++;
    } else {
      TestEncoder_DW.position_accumulated_h--;
    }
  }

  TestEncoder_DW.previousA_a = TestEncoder_B.DigitalPortRead_j;
  TestEncoder_B.position_e = TestEncoder_DW.position_accumulated_h;

  /* End of MATLAB Function: '<Root>/MATLAB Function4' */
  /* MATLAB Function: '<Root>/MATLAB Function5' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   *  DataTypeConversion: '<Root>/Data Type Conversion4'
   */
  if (!TestEncoder_DW.previousA_not_empty_a) {
    TestEncoder_DW.previousA_c = TestEncoder_B.DigitalPortRead_j;
    TestEncoder_DW.previousA_not_empty_a = true;
  }

  if (TestEncoder_B.DigitalPortRead_o.DigitalPortRead) {
    TestEncoder_DW.position_accumulated_n = 0.0;
  } else if ((TestEncoder_DW.previousA_c == 0.0) &&
             TestEncoder_B.DigitalPortRead_j) {
    if (!TestEncoder_B.DigitalPortRead_g) {
      TestEncoder_DW.position_accumulated_n++;
    } else {
      TestEncoder_DW.position_accumulated_n--;
    }
  } else if ((TestEncoder_DW.previousA_c == 1.0) &&
             (!TestEncoder_B.DigitalPortRead_j)) {
    if (TestEncoder_B.DigitalPortRead_g) {
      TestEncoder_DW.position_accumulated_n++;
    } else {
      TestEncoder_DW.position_accumulated_n--;
    }
  }

  TestEncoder_DW.previousA_c = TestEncoder_B.DigitalPortRead_j;
  TestEncoder_B.position_g = TestEncoder_DW.position_accumulated_n;

  /* End of MATLAB Function: '<Root>/MATLAB Function5' */
  /* MATLAB Function: '<Root>/MATLAB Function6' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   *  DataTypeConversion: '<Root>/Data Type Conversion4'
   */
  if (!TestEncoder_DW.previousA_not_empty) {
    TestEncoder_DW.previousA = TestEncoder_B.DigitalPortRead_j;
    TestEncoder_DW.previousA_not_empty = true;
    TestEncoder_DW.previousB = TestEncoder_B.DigitalPortRead_g;
  }

  if (TestEncoder_B.DigitalPortRead_o.DigitalPortRead) {
    TestEncoder_DW.position_accumulated = 0.0;
  } else if ((TestEncoder_DW.previousA == 0.0) &&
             TestEncoder_B.DigitalPortRead_j) {
    if (!TestEncoder_B.DigitalPortRead_g) {
      TestEncoder_DW.position_accumulated++;
    } else {
      TestEncoder_DW.position_accumulated--;
    }
  } else if ((TestEncoder_DW.previousA == 1.0) &&
             (!TestEncoder_B.DigitalPortRead_j)) {
    if (TestEncoder_B.DigitalPortRead_g) {
      TestEncoder_DW.position_accumulated++;
    } else {
      TestEncoder_DW.position_accumulated--;
    }
  } else if ((TestEncoder_DW.previousB == 0.0) &&
             TestEncoder_B.DigitalPortRead_g) {
    if (TestEncoder_B.DigitalPortRead_j) {
      TestEncoder_DW.position_accumulated++;
    } else {
      TestEncoder_DW.position_accumulated--;
    }
  } else if ((TestEncoder_DW.previousB == 1.0) &&
             (!TestEncoder_B.DigitalPortRead_g)) {
    if (!TestEncoder_B.DigitalPortRead_j) {
      TestEncoder_DW.position_accumulated++;
    } else {
      TestEncoder_DW.position_accumulated--;
    }
  }

  TestEncoder_DW.previousA = TestEncoder_B.DigitalPortRead_j;
  TestEncoder_DW.previousB = TestEncoder_B.DigitalPortRead_g;
  TestEncoder_B.position = TestEncoder_DW.position_accumulated;

  /* End of MATLAB Function: '<Root>/MATLAB Function6' */

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  TestEncoder_M->Timing.taskTime0 =
    ((time_T)(++TestEncoder_M->Timing.clockTick0)) *
    TestEncoder_M->Timing.stepSize0;
}

/* Model initialize function */
void TestEncoder_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(TestEncoder_M, -1);
  TestEncoder_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  TestEncoder_M->Sizes.checksums[0] = (4132773311U);
  TestEncoder_M->Sizes.checksums[1] = (1988424018U);
  TestEncoder_M->Sizes.checksums[2] = (3765351464U);
  TestEncoder_M->Sizes.checksums[3] = (2784035055U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[14];
    TestEncoder_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    systemRan[12] = &rtAlwaysEnabled;
    systemRan[13] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(TestEncoder_M->extModeInfo,
      &TestEncoder_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(TestEncoder_M->extModeInfo,
                        TestEncoder_M->Sizes.checksums);
    rteiSetTPtr(TestEncoder_M->extModeInfo, rtmGetTPtr(TestEncoder_M));
  }

  /* Start for MATLABSystem: '<Root>/Encoder' */
  TestEncoder_DW.obj_p.isInitialized = 0;
  TestEncoder_DW.obj_p.matlabCodegenIsDeleted = false;
  TestEncoder_SystemCore_setup(&TestEncoder_DW.obj_p);
  TestEncode_DigitalPortRead_Init(&TestEncoder_DW.DigitalPortRead);

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  TestEncoder_DW.obj_h.isInitialized = 0;
  TestEncoder_DW.obj_h.matlabCodegenIsDeleted = false;
  TestEncoder_SystemCore_setup_n(&TestEncoder_DW.obj_h);

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  TestEncoder_DW.obj.isInitialized = 0;
  TestEncoder_DW.obj.matlabCodegenIsDeleted = false;
  TestEncoder_SystemCore_setup_nb(&TestEncoder_DW.obj);
  TestEncode_DigitalPortRead_Init(&TestEncoder_DW.DigitalPortRead_o);
}

/* Model terminate function */
void TestEncoder_terminate(void)
{
  uint8_T ChannelInfo;

  /* Terminate for MATLABSystem: '<Root>/Encoder' */
  if (!TestEncoder_DW.obj_p.matlabCodegenIsDeleted) {
    TestEncoder_DW.obj_p.matlabCodegenIsDeleted = true;
    if ((TestEncoder_DW.obj_p.isInitialized == 1) &&
        TestEncoder_DW.obj_p.isSetupComplete) {
      disableCounter(TestEncoder_DW.obj_p.TimerHandle);
      disableTimerInterrupts(TestEncoder_DW.obj_p.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(TestEncoder_DW.obj_p.TimerHandle, ChannelInfo);
      disableTimerChannel2(TestEncoder_DW.obj_p.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder' */
  /* Terminate for MATLABSystem: '<Root>/Encoder1' */
  if (!TestEncoder_DW.obj_h.matlabCodegenIsDeleted) {
    TestEncoder_DW.obj_h.matlabCodegenIsDeleted = true;
    if ((TestEncoder_DW.obj_h.isInitialized == 1) &&
        TestEncoder_DW.obj_h.isSetupComplete) {
      disableCounter(TestEncoder_DW.obj_h.TimerHandle);
      disableTimerInterrupts(TestEncoder_DW.obj_h.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(TestEncoder_DW.obj_h.TimerHandle, ChannelInfo);
      disableTimerChannel2(TestEncoder_DW.obj_h.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder1' */
  /* Terminate for MATLABSystem: '<Root>/Encoder2' */
  if (!TestEncoder_DW.obj.matlabCodegenIsDeleted) {
    TestEncoder_DW.obj.matlabCodegenIsDeleted = true;
    if ((TestEncoder_DW.obj.isInitialized == 1) &&
        TestEncoder_DW.obj.isSetupComplete) {
      disableCounter(TestEncoder_DW.obj.TimerHandle);
      disableTimerInterrupts(TestEncoder_DW.obj.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(TestEncoder_DW.obj.TimerHandle, ChannelInfo);
      disableTimerChannel2(TestEncoder_DW.obj.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder2' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
