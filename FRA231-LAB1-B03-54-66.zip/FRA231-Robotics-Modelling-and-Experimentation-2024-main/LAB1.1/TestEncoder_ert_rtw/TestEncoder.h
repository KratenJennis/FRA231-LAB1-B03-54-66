/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: TestEncoder.h
 *
 * Code generated for Simulink model 'TestEncoder'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Wed Oct 30 12:43:45 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef TestEncoder_h_
#define TestEncoder_h_
#ifndef TestEncoder_COMMON_INCLUDES_
#define TestEncoder_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "math.h"
#include "main.h"
#endif                                 /* TestEncoder_COMMON_INCLUDES_ */

#include "TestEncoder_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals for system '<S12>/Digital Port Read' */
typedef struct {
  boolean_T DigitalPortRead;           /* '<S12>/Digital Port Read' */
} B_DigitalPortRead_TestEncoder_T;

/* Block states (default storage) for system '<S12>/Digital Port Read' */
typedef struct {
  stm32cube_blocks_DigitalPortR_T obj; /* '<S12>/Digital Port Read' */
  boolean_T objisempty;                /* '<S12>/Digital Port Read' */
} DW_DigitalPortRead_TestEncode_T;

/* Block signals (default storage) */
typedef struct {
  real_T position;                     /* '<Root>/MATLAB Function6' */
  real_T position_g;                   /* '<Root>/MATLAB Function5' */
  real_T position_e;                   /* '<Root>/MATLAB Function4' */
  real_T X1pulse;                      /* '<Root>/MATLAB Function3' */
  real_T X4pulse;                      /* '<Root>/MATLAB Function2' */
  real_T X2pulse;                      /* '<Root>/MATLAB Function1' */
  uint32_T bX1;                        /* '<Root>/Encoder2' */
  uint32_T bX2;                        /* '<Root>/Encoder1' */
  uint32_T bX4;                        /* '<Root>/Encoder' */
  boolean_T DigitalPortRead_g;         /* '<S16>/Digital Port Read' */
  boolean_T DigitalPortRead_j;         /* '<S14>/Digital Port Read' */
  B_DigitalPortRead_TestEncoder_T DigitalPortRead_o;/* '<S12>/Digital Port Read' */
  B_DigitalPortRead_TestEncoder_T DigitalPortRead;/* '<S12>/Digital Port Read' */
} B_TestEncoder_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  stm32cube_blocks_EncoderBlock_T obj; /* '<Root>/Encoder2' */
  stm32cube_blocks_EncoderBlock_T obj_h;/* '<Root>/Encoder1' */
  stm32cube_blocks_EncoderBlock_T obj_p;/* '<Root>/Encoder' */
  real_T previousA;                    /* '<Root>/MATLAB Function6' */
  real_T previousB;                    /* '<Root>/MATLAB Function6' */
  real_T position_accumulated;         /* '<Root>/MATLAB Function6' */
  real_T previousA_c;                  /* '<Root>/MATLAB Function5' */
  real_T position_accumulated_n;       /* '<Root>/MATLAB Function5' */
  real_T previousA_a;                  /* '<Root>/MATLAB Function4' */
  real_T position_accumulated_h;       /* '<Root>/MATLAB Function4' */
  real_T bcount;                       /* '<Root>/MATLAB Function3' */
  real_T xcount;                       /* '<Root>/MATLAB Function3' */
  real_T bcount_c;                     /* '<Root>/MATLAB Function2' */
  real_T xcount_e;                     /* '<Root>/MATLAB Function2' */
  real_T bcount_m;                     /* '<Root>/MATLAB Function1' */
  real_T xcount_o;                     /* '<Root>/MATLAB Function1' */
  boolean_T previousA_not_empty;       /* '<Root>/MATLAB Function6' */
  boolean_T previousA_not_empty_a;     /* '<Root>/MATLAB Function5' */
  boolean_T previousA_not_empty_b;     /* '<Root>/MATLAB Function4' */
  boolean_T bcount_not_empty;          /* '<Root>/MATLAB Function3' */
  boolean_T bcount_not_empty_p;        /* '<Root>/MATLAB Function2' */
  boolean_T bcount_not_empty_c;        /* '<Root>/MATLAB Function1' */
  DW_DigitalPortRead_TestEncode_T DigitalPortRead_o;/* '<S12>/Digital Port Read' */
  DW_DigitalPortRead_TestEncode_T DigitalPortRead;/* '<S12>/Digital Port Read' */
} DW_TestEncoder_T;

/* Real-time Model Data Structure */
struct tag_RTM_TestEncoder_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block signals (default storage) */
extern B_TestEncoder_T TestEncoder_B;

/* Block states (default storage) */
extern DW_TestEncoder_T TestEncoder_DW;

/* Model entry point functions */
extern void TestEncoder_initialize(void);
extern void TestEncoder_step(void);
extern void TestEncoder_terminate(void);

/* Real-time Model object */
extern RT_MODEL_TestEncoder_T *const TestEncoder_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'TestEncoder'
 * '<S1>'   : 'TestEncoder/Digital Port Read'
 * '<S2>'   : 'TestEncoder/Digital Port Read1'
 * '<S3>'   : 'TestEncoder/Digital Port Read2'
 * '<S4>'   : 'TestEncoder/Digital Port Read3'
 * '<S5>'   : 'TestEncoder/MATLAB Function1'
 * '<S6>'   : 'TestEncoder/MATLAB Function2'
 * '<S7>'   : 'TestEncoder/MATLAB Function3'
 * '<S8>'   : 'TestEncoder/MATLAB Function4'
 * '<S9>'   : 'TestEncoder/MATLAB Function5'
 * '<S10>'  : 'TestEncoder/MATLAB Function6'
 * '<S11>'  : 'TestEncoder/Digital Port Read/ECSoC'
 * '<S12>'  : 'TestEncoder/Digital Port Read/ECSoC/ECSimCodegen'
 * '<S13>'  : 'TestEncoder/Digital Port Read1/ECSoC'
 * '<S14>'  : 'TestEncoder/Digital Port Read1/ECSoC/ECSimCodegen'
 * '<S15>'  : 'TestEncoder/Digital Port Read2/ECSoC'
 * '<S16>'  : 'TestEncoder/Digital Port Read2/ECSoC/ECSimCodegen'
 * '<S17>'  : 'TestEncoder/Digital Port Read3/ECSoC'
 * '<S18>'  : 'TestEncoder/Digital Port Read3/ECSoC/ECSimCodegen'
 */
#endif                                 /* TestEncoder_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
